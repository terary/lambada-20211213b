import type { IVisitor } from "../DirectedTreeGraph";
import type { TPredicateNode } from "../../index";

export interface IVisitorPredicateTree extends IVisitor<TPredicateNode> {}

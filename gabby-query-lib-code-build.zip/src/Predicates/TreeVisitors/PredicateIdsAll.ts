import { PredicateIdsAbstract } from "./PredicateIdsAbstract";

export class PredicateIdsAll extends PredicateIdsAbstract {}

import { predicateFormula } from "./ExamplePredicateFormulaEditor";

export { predicateFormula };
